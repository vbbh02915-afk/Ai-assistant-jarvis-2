JARVIS LITE — Android starter app

যা আছে:
- Chat-style interface
- Microphone দিয়ে Android speech recognition
- Text-to-speech উত্তর
- সময়/তারিখ বলা
- YouTube ও Google খোলা
- বর্তমানে এটি offline demo; ChatGPT/Gemini-এর মতো real AI উত্তর দেয় না।

APK build সম্পর্কে গুরুত্বপূর্ণ:
Android SDK + Build Tools ছাড়া শুধু Termux-এ Gradle চালালেই APK হবে না। Android SDK সেটআপ করা থাকলে নিচের কমান্ড ব্যবহার করুন।

1) ZIP extract করুন:
   unzip JarvisLite.zip
   cd JarvisLite

2) Java/Gradle install:
   pkg update -y
   pkg install openjdk-17 gradle unzip -y

3) Android SDK environment আগে থেকেই সেটআপ থাকলে:
   export ANDROID_HOME=$HOME/android-sdk
   export ANDROID_SDK_ROOT=$ANDROID_HOME
   export PATH=$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/35.0.0

4) Project build:
   gradle assembleDebug

5) APK path:
   app/build/outputs/apk/debug/app-debug.apk

নোট:
- Termux-এ Android SDK/Build Tools ইনস্টল ও চালানো ডিভাইসভেদে জটিল/অসমর্থিত হতে পারে।
- সহজ ও নির্ভরযোগ্য উপায়: project-টি Android Studio-তে খুলে Build > Build APK(s)।
- Termux-এ SDK না থাকলে GitHub Actions/Android Studio দিয়ে build করতে হবে।
- Microphone permission চাইলে Allow দিন।
