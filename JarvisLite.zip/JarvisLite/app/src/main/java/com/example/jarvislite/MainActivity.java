package com.example.jarvislite;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private static final int REQ_SPEECH = 101;
    private final int bg = Color.rgb(8, 15, 30);
    private final int cyan = Color.rgb(0, 220, 255);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault());
        });
        buildUi();
        addMessage("JARVIS", "Hello! I am Jarvis Lite. Tap the mic and speak, or type a message.");
    }

    private TextView label(String text, int size, int color) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        return v;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18, 18, 18, 12);
        root.setBackgroundColor(bg);
        setContentView(root);

        TextView title = label("J.A.R.V.I.S", 27, cyan);
        title.setTypeface(Typeface.DEFAULT_BOLD); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 54));
        TextView subtitle = label("PERSONAL AI ASSISTANT  •  LITE", 11, Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, 28));

        scroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(4, 12, 4, 12);
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL); bar.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setSingleLine(true); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY);
        input.setHint("Ask me anything...");
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan));
        bar.addView(input, new LinearLayout.LayoutParams(0, 54, 1));

        Button mic = new Button(this); mic.setText("🎙");
        mic.setOnClickListener(v -> startVoice());
        bar.addView(mic, new LinearLayout.LayoutParams(58, 54));

        Button send = new Button(this); send.setText("SEND");
        send.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (!q.isEmpty()) { input.setText(""); handle(q); }
        });
        bar.addView(send, new LinearLayout.LayoutParams(78, 54));
        root.addView(bar);
    }

    private void addMessage(String who, String text) {
        TextView v = label(who + "\\n" + text, 15, who.equals("YOU") ? Color.WHITE : cyan);
        v.setPadding(13, 12, 13, 12);
        v.setBackgroundColor(Color.rgb(18, 31, 52));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 7, 0, 7);
        messages.addView(v, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void handle(String q) {
        addMessage("YOU", q);
        String s = q.toLowerCase(Locale.ROOT);
        String answer;
        if (s.contains("time") || s.contains("সময়") || s.contains("সময়")) {
            answer = "The time is " + new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
        } else if (s.contains("date") || s.contains("তারিখ")) {
            answer = "Today is " + new SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(new Date());
        } else if (s.contains("hello") || s.contains("হ্যালো") || s.contains("hi")) {
            answer = "Hello! How can I help you?";
        } else if (s.contains("open youtube")) {
            answer = "Opening YouTube.";
            try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com"))); }
            catch (Exception e) { answer = "I could not open YouTube."; }
        } else if (s.contains("open google")) {
            answer = "Opening Google.";
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")));
        } else if (s.contains("who are you") || s.contains("তুমি কে")) {
            answer = "I am Jarvis Lite, your simple Android voice assistant.";
        } else {
            answer = "I heard you say: " + q + ". I am currently running in offline demo mode. To get real AI answers, connect an AI API in a future version.";
        }
        addMessage("JARVIS", answer);
        if (tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("JARVIS", "Speech recognition is not available on this device.");
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Jarvis");
        try { startActivityForResult(intent, REQ_SPEECH); }
        catch (Exception e) { addMessage("JARVIS", "Could not start voice input."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) handle(results.get(0));
        }
    }

    @Override public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (recognizer != null) recognizer.destroy();
        super.onDestroy();
    }
}
